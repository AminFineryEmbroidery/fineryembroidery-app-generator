# FineryEmbroidery App

App to automate Shopify product description generation based on uploaded images.